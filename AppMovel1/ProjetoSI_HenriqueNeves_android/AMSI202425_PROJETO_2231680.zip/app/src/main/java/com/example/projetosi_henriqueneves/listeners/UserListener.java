package com.example.projetosi_henriqueneves.listeners;

public interface UserListener {
    void onRefreshDetails(int op);
}
