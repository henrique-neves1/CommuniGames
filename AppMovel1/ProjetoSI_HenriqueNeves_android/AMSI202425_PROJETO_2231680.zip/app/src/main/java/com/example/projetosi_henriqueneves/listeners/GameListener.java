package com.example.projetosi_henriqueneves.listeners;

public interface GameListener {
    void onRefreshDetails(int op);
}
